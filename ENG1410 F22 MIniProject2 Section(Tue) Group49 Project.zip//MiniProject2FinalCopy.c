#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct {
  char name[256];
  float lat;
  float lon;
  float alt;
  unsigned long long time;
} user_t;

typedef struct {
    char name[256];
    float distance;
} user_distance;

void getLine(FILE *fp, char *array);

void scan_user(user_t *ptr_user_t_instance, FILE *fp, char *array);

void distance(user_t my_user, user_t other_users, int usersNum, user_distance *users);

int minvalue(int usersNum, user_distance users[]);






int main() {
  user_t my_user, other_users[50];
  user_distance users[50];
  int usersNum;
  char line[250];
  char filename[1000] = {0}, outputFilename[1000] = {0};
  
  printf("Enter the filename or path: ");
  scanf("%s", &filename);
  

  // File opening
  FILE *fp;
  fp = fopen(filename, "r");
  if (fp == NULL) {
    printf("Error opening file! - %s\n", filename);
    return 1;
  }
  //using getLine and adding it to userNum using atoi function
  getLine(fp, line);
  usersNum = atoi(line);

  //using all functions and printing results
  printf("\n\nMy User Information:\n\n");
  printf("number of users is: %d\n", usersNum);
  scan_user(&my_user, fp, line);
  printf("The users name is %s\n", my_user.name);
  printf("The users time is %u\n", my_user.time);
  printf("The users lat is %f\n", my_user.lat);
  printf("The users lon is %f\n", my_user.lon);
  printf("The users alt is %f\n", my_user.alt);

  for (int cntr = 0; cntr < usersNum; cntr++) {
    scan_user(&other_users[cntr], fp, line);
  }
  printf("\n\nOther Users Information:\n\n");
  for (int cntr = 0; cntr < usersNum; cntr++) {
    printf("The users name is %s\n", other_users[cntr].name);
    printf("The users time is %u\n", other_users[cntr].time);
    printf("The users lat is %f\n", other_users[cntr].lat);
    printf("The users lon is %f\n", other_users[cntr].lon);
    printf("The users alt is %f\n", other_users[cntr].alt);
  }
  printf("\n\nDistances:\n\n");
  
  for(int cntr=0;cntr<usersNum;cntr++){
  distance(my_user, other_users[cntr], usersNum, &users[cntr]);  
  }

  for(int cntr=0;cntr<usersNum;cntr++){
  printf("The name of the user is %s and the distance of the user is %f\n", users[cntr].name,users[cntr].distance);
  }

  minvalue(usersNum, users);
  
  

  return 0;
}

void getLine(FILE *fp, char *array) {
  char x = 0;
  int counter = 0;

  while ((x = fgetc(fp)) != EOF) {
    if (x != '\n') {
      array[counter] = x;
      counter++;
      // printf(" %c ",array[counter-1]);
    } else {
      break;
    }
  }
  // printf("\n");
  array[counter] = '\0';
}

void scan_user(user_t *ptr_user_t_instance, FILE *fp, char *array) {
  // Each user is defined like below:
  //<name>
  //<lattitude>
  //<longitude>
  //<altitude>
  //<time in nanoseconds>

  getLine(fp, array);
  strcpy(ptr_user_t_instance->name, array);
  // printf("Name: %s\n", ptr_user_t_instance->name);
  getLine(fp, array);
  ptr_user_t_instance->time = strtoull(array, NULL, 10);
  // printf("time: %u\n", ptr_user_t_instance->time);
  getLine(fp, array);
  ptr_user_t_instance->lat = atof(array);
  // printf("Latitude: %f\n", ptr_user_t_instance->lat);
  getLine(fp, array);
  ptr_user_t_instance->lon = atof(array);
  // printf("Longitude: %f\n", ptr_user_t_instance->lon);

  getLine(fp, array);
  ptr_user_t_instance->alt = atof(array);
  // printf("Altitude: %f\n", ptr_user_t_instance->lat);
}

void distance(user_t my_user, user_t other_users, int usersNum, user_distance *users) {
  int i;
  float lat1 = my_user.lat;
  float lon1 = my_user.lon;
  float alt1 = my_user.alt;
  float diff_position;
  
    float lat2 = other_users.lat;
    float lon2 = other_users.lon;
    float alt2 = other_users.alt;
    diff_position = sqrt(pow(lat1 - lat2, 2) + pow(lon1 - lon2, 2) + pow(alt1 - alt2, 2));
    strcpy(users->name, other_users.name);
    users->distance = diff_position;
  
}

int minvalue(int usersNum, user_distance users[]) {
  int smallest = -1;
  float min_value=users[0].distance;
   
  
    for(int i=1; i<usersNum;i++){
        if (users[i].distance<min_value ) {
        smallest = i;
        min_value=users[i].distance;
        }
    }
  
  printf("\nThe user closest to our user is: %s and the distance is: %f\n\n", users[smallest].name,users[smallest].distance);
  return smallest;
}
